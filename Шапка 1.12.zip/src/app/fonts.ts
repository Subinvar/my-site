export const headingFont = { variable: 'font-heading-var' };

export const bodyFont = { variable: 'font-body-var' };
