import type { ContentFormField } from "../api.d.ts";
export declare function emptyContent(opts: {
    extension: 'mdoc' | 'md' | 'mdx';
}): ContentFormField<null, null, null>;
