import type { BasicFormField } from "../api.d.ts";
export declare function empty(): BasicFormField<null>;
