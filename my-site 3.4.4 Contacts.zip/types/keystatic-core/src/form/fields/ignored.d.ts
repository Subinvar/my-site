import type { BasicFormField, FormFieldStoredValue } from "../api.d.ts";
export declare function ignored(): BasicFormField<{
    value: FormFieldStoredValue;
}, {
    value: FormFieldStoredValue;
}, unknown>;
