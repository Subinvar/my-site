/** @deprecated Experimental */
export declare function cloudImage(args: {
    label: string;
}): import("../form/api.d.ts").ComponentBlock<{
    src: import("../form/api.d.ts").SlugFormField<string, string, string, null>;
    alt: import("../form/api.d.ts").SlugFormField<string, string, string, null>;
    height: import("../form/api.d.ts").BasicFormField<number | null, number | null>;
    width: import("../form/api.d.ts").BasicFormField<number | null, number | null>;
}>;
