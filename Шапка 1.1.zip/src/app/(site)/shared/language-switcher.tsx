import Link from 'next/link';

import { buttonClassNames } from '@/app/(site)/shared/ui/button-classes';
import type { Locale } from '@/lib/i18n';
import { cn } from '@/lib/cn';

type LanguageSwitcherProps = {
  currentLocale: Locale;
  targetLocale: Locale;
  href: string | null;
  switchToLabels: Record<Locale, string>;
};

export function LanguageSwitcher({
  currentLocale,
  targetLocale,
  href,
  switchToLabels,
}: LanguageSwitcherProps) {
  const targetHref = href ?? null;
  const isDisabled = targetHref === null;
  const ariaLabelValue = switchToLabels[targetLocale];
  const ariaLabel = ariaLabelValue && ariaLabelValue.trim().length ? ariaLabelValue : undefined;

  // Пишем, куда переключаемся
  const label = currentLocale === 'ru' ? 'EN' : 'RU';

  // Фиксированная ширина + капсула + без подчёркивания
  const baseClasses =
    'relative overflow-hidden rounded-full border border-border shadow-sm uppercase tracking-[0.08em] no-underline w-12 bg-transparent';

  if (isDisabled) {
    return (
      <span
        className={buttonClassNames({
          variant: 'ghost',
          size: 'sm',
          className: cn(
            baseClasses,
            // На всякий случай тоже гасим фон на hover
            'opacity-50 hover:bg-transparent focus-visible:bg-transparent',
          ),
        })}
        aria-label={ariaLabel}
        aria-disabled="true"
        role="link"
      >
        <span className="relative z-10">{label}</span>
      </span>
    );
  }

  return (
    <Link
      href={targetHref}
      className={buttonClassNames({
        variant: 'ghost',
        size: 'sm',
        className: cn(
          baseClasses,
          'group',
          // Главное: перекрываем hover-стили ghost-варианта
          'hover:bg-transparent focus-visible:bg-transparent',
        ),
      })}
      aria-label={ariaLabel}
    >
      {/* Подсветка: теперь ЕДИНСТВЕННАЯ «заливка» */}
      <span
        aria-hidden
        className={cn(
          'pointer-events-none absolute inset-0 translate-y-full bg-brand-50',
          'transition-transform duration-300 ease-out',
          'group-hover:translate-y-0 group-focus-visible:translate-y-0 group-active:translate-y-0',
        )}
      />

      {/* Текст: лёгкое движение, синхронное по времени */}
      <span className="relative z-10 transition-transform duration-300 ease-out group-hover:-translate-y-[1px] group-active:translate-y-[1px]">
        {label}
      </span>
    </Link>
  );
}