export { Keystatic } from "./app/ui.d.ts";
export type { Router } from "./app/router.d.ts";
