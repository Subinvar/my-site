import type { ContentFormField } from "../api.d.ts";
/**
 * @deprecated `emptyDocument` has been replaced with the `emptyContent` field
 */
export declare function emptyDocument(): ContentFormField<null, null, null>;
