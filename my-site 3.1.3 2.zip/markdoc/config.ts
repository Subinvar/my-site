import { config } from "../src/lib/markdoc";

export default config;