import type { HTMLAttributes } from 'react';
export declare const NotEditable: import("react").ForwardRefExoticComponent<HTMLAttributes<HTMLDivElement> & import("react").RefAttributes<HTMLDivElement>>;
