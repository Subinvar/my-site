export { getAllowedDirectories } from "./read-local.d.ts";
