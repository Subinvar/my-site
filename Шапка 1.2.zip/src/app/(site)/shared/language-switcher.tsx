'use client';

import Link from 'next/link';
import { useLayoutEffect, useRef, useState } from 'react';

import { buttonClassNames } from '@/app/(site)/shared/ui/button-classes';
import type { Locale } from '@/lib/i18n';
import { cn } from '@/lib/cn';

type LanguageSwitcherProps = {
  currentLocale: Locale;
  targetLocale: Locale;
  href: string | null;
  switchToLabels: Record<Locale, string>;
};

const LANG_SWITCH_FLAG = 'intemaLangSwitchHover';

export function LanguageSwitcher({
  currentLocale,
  targetLocale,
  href,
  switchToLabels,
}: LanguageSwitcherProps) {
  const targetHref = href ?? null;
  const isDisabled = targetHref === null;
  const ariaLabelValue = switchToLabels[targetLocale];
  const ariaLabel = ariaLabelValue && ariaLabelValue.trim().length ? ariaLabelValue : undefined;

  // Показываем, КУДА переключимся
  const label = currentLocale === 'ru' ? 'EN' : 'RU';

  // Базовый вид кнопки: капсула фиксированной ширины, без подчёркивания
  const baseClasses =
    'relative overflow-hidden rounded-full border border-border shadow-sm uppercase tracking-[0.08em] no-underline w-12 bg-transparent';

  const linkRef = useRef<HTMLAnchorElement | null>(null);

  // Считаем, что по умолчанию кнопка ЗАЛИТА (чтобы не было "белого" кадра при перезагрузке с hover)
  const [isFilled, setIsFilled] = useState(true);
  // Когда false — первый переход filled → empty делаем без анимации
  const [enableTransition, setEnableTransition] = useState(false);

  const readSwitchFlag = () => {
    try {
      return typeof window !== 'undefined' && window.sessionStorage.getItem(LANG_SWITCH_FLAG) === '1';
    } catch {
      return false;
    }
  };

  const clearSwitchFlag = () => {
    try {
      if (typeof window === 'undefined') return;
      window.sessionStorage.removeItem(LANG_SWITCH_FLAG);
    } catch {
      // игнорируем
    }
  };

  useLayoutEffect(() => {
    if (typeof window === 'undefined') return;
    const node = linkRef.current;
    if (!node) return;

    const hoveredOnMount = node.matches(':hover');
    const fromSwitch = readSwitchFlag();

    if (fromSwitch) {
      clearSwitchFlag();
    }

    // Если не из переключателя и курсор НЕ над кнопкой — делаем её пустой (без анимации)
    if (!hoveredOnMount && !fromSwitch) {
      setIsFilled(false);
    }

    // Со следующего кадра включаем анимации для всех будущих hover/leave
    window.requestAnimationFrame(() => {
      setEnableTransition(true);
    });
  }, []);

  const markSwitchInSession = () => {
    if (typeof window === 'undefined') return;
    try {
      const node = linkRef.current;
      const hovered = node?.matches(':hover') ?? false;

      if (!hovered) {
        // если клик был не с hover — флаг не нужен
        clearSwitchFlag();
        return;
      }

      window.sessionStorage.setItem(LANG_SWITCH_FLAG, '1');
    } catch {
      // живём без спец-логики, если sessionStorage недоступен
    }
  };

  const handleMouseEnter = () => setIsFilled(true);
  const handleFocus = () => setIsFilled(true);
  const handleMouseLeave = () => setIsFilled(false);
  const handleBlur = () => setIsFilled(false);

  if (isDisabled) {
    return (
      <span
        className={buttonClassNames({
          variant: 'ghost',
          size: 'sm',
          className: cn(
            baseClasses,
            'opacity-50 hover:bg-transparent focus-visible:bg-transparent',
          ),
        })}
        aria-label={ariaLabel}
        aria-disabled="true"
        role="link"
      >
        <span className="relative z-10">{label}</span>
      </span>
    );
  }

  return (
    <Link
      href={targetHref}
      ref={linkRef}
      onClick={markSwitchInSession}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      onFocus={handleFocus}
      onBlur={handleBlur}
      className={buttonClassNames({
        variant: 'ghost',
        size: 'sm',
        className: cn(
          baseClasses,
          'group',
          // Глушим фон ghost-варианта, чтобы "заливка" была только наша
          'hover:bg-transparent focus-visible:bg-transparent',
        ),
      })}
      aria-label={ariaLabel}
    >
      {/* Заливка: управляем только стейтом isFilled */}
      <span
        aria-hidden
        className={cn(
          'pointer-events-none absolute inset-0 bg-brand-50',
          enableTransition && 'transition-transform duration-300 ease-out',
          isFilled ? 'translate-y-0' : 'translate-y-full',
        )}
      />

      {/* Текст: лёгкое "подпрыгивание" на hover/active */}
      <span className="relative z-10 transition-transform duration-300 ease-out group-hover:-translate-y-[1px] group-active:translate-y-[1px]">
        {label}
      </span>
    </Link>
  );
}
