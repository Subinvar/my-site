import type { ReactNode } from 'react';
import Image from 'next/image';
import localFont from 'next/font/local';

import { getInterfaceDictionary } from '@/content/dictionary';
import { NavigationList } from '@/app/[locale]/navigation-list';
import { formatTelegramHandle } from '@/lib/contacts';
import type { Navigation, SiteContent } from '@/lib/keystatic';
import type { Locale } from '@/lib/i18n';
import { buildPath } from '@/lib/paths';
import { LanguageSwitcher } from './language-switcher';
import { HtmlLangSync } from './html-lang-sync';
import { ThemeToggle } from './theme-toggle';

const brandFont = localFont({
  src: [
    {
      path: '../../../../public/fonts/geist/Geist-Regular.woff2',
      weight: '400',
      style: 'normal',
    },
    {
      path: '../../../../public/fonts/geist/Geist-SemiBold.woff2',
      weight: '600',
      style: 'normal',
    },
  ],
  preload: true,
  display: 'swap',
  variable: '--font-brand',
});

type SiteShellProps = {
  locale: Locale;
  targetLocale: Locale;
  site: SiteContent;
  navigation: Navigation;
  switcherHref: string | null;
  currentPath: string;
  children: ReactNode;
};

function SkipToContentLink({ label }: { label: string }) {
  return (
    <a
      href="#main"
      className="sr-only focus-visible:absolute focus-visible:left-4 focus-visible:top-4 focus-visible:not-sr-only focus-visible:rounded focus-visible:bg-brand-600 focus-visible:px-4 focus-visible:py-2 focus-visible:text-white focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-600"
    >
      {label}
    </a>
  );
}

export function SiteShell({
  locale,
  targetLocale,
  site,
  navigation,
  switcherHref,
  currentPath,
  children,
}: SiteShellProps) {
  const brandName = site.name?.trim() ?? '';
  const hasBrandName = brandName.length > 0;
  const dictionary = getInterfaceDictionary(locale);
  const skipLinkLabel = dictionary.common.skipToContent;
  const navigationLabels = dictionary.navigation;
  const switchToLabels = dictionary.languageSwitcher.switchTo;
  const telegramUrl = site.contacts.telegramUrl?.trim() ?? '';
  const telegramLabel = formatTelegramHandle(telegramUrl) ?? (telegramUrl ? 'Telegram' : '');
  const contactLinks = [
    site.contacts.phone
      ? {
          id: 'phone',
          label: site.contacts.phone,
          href: `tel:${site.contacts.phone}`,
        }
      : null,
    site.contacts.email
      ? {
          id: 'email',
          label: site.contacts.email,
          href: `mailto:${site.contacts.email}`,
        }
      : null,
    telegramUrl
      ? {
          id: 'telegram',
          label: telegramLabel || telegramUrl,
          href: telegramUrl,
        }
      : null,
  ].filter((item): item is { id: string; label: string; href: string } => Boolean(item));

  const hasContacts = contactLinks.length > 0 || Boolean(site.contacts.address);
  const currentYear = new Date().getFullYear();
  const copyrightTemplate = site.footer?.copyright?.trim() ?? '';
  const copyrightText = copyrightTemplate.length
    ? copyrightTemplate.replaceAll('{year}', String(currentYear)).replaceAll('{siteName}', brandName)
    : '';
  const hasCopyright = copyrightText.length > 0;

  return (
    <div className={`${brandFont.variable} flex min-h-screen flex-col bg-background text-foreground`}>
      <HtmlLangSync initialLocale={locale} />
      <SkipToContentLink label={skipLinkLabel} />
      <header className="sticky top-0 z-40 border-b border-border bg-background/80 backdrop-blur">
        {hasContacts ? (
          <div className="border-b border-brand-100 bg-brand-900 text-xs text-brand-50 sm:text-sm">
            <div className="mx-auto flex w-full max-w-5xl flex-wrap items-center gap-3 px-4 py-2 sm:px-6">
              {contactLinks.map((link) => (
                <a
                  key={link.id}
                  href={link.href}
                  className="inline-flex items-center gap-2 text-xs sm:text-sm text-brand-50 hover:text-brand-100 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-600"
                >
                  {link.label}
                </a>
              ))}
              {site.contacts.address ? (
                <span className="text-xs text-brand-100/80 sm:text-sm">{site.contacts.address}</span>
              ) : null}
            </div>
          </div>
        ) : null}
        <div className="mx-auto w-full max-w-5xl px-4 py-4 sm:px-6 sm:py-5">
          <div className="flex flex-col gap-6 sm:flex-row sm:items-center sm:justify-between">
            <a
              href={buildPath(locale)}
              className="flex items-center gap-4 text-left focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-600"
            >
              <span className="relative flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-xl bg-brand-600">
                <Image src="/uploads/logo.svg" alt={brandName || 'Интема Групп'} width={40} height={40} />
              </span>
              <span className="space-y-1">
                {hasBrandName ? (
                  <span className="text-xs font-semibold uppercase tracking-[0.2em] text-brand-700">{brandName}</span>
                ) : null}
                {site.tagline ? (
                  <span className="block text-2xl font-semibold text-foreground">{site.tagline}</span>
                ) : null}
              </span>
            </a>
            <div className="flex flex-col items-start gap-6 sm:flex-row sm:items-center">
              <NavigationList
                links={navigation.header}
                ariaLabel={navigationLabels.headerLabel}
                currentPath={currentPath}
              />
              <div className="flex items-center gap-3">
                <ThemeToggle />
                <LanguageSwitcher
                  currentLocale={locale}
                  targetLocale={targetLocale}
                  href={switcherHref}
                  switchToLabels={switchToLabels}
                />
              </div>
            </div>
          </div>
        </div>
      </header>
      <main
        id="main"
        role="main"
        tabIndex={-1}
        className="mx-auto w-full max-w-5xl flex-1 px-6 py-12"
      >
        {children}
      </main>
      <footer className="border-t border-border bg-background">
        <div className="mx-auto flex w-full max-w-5xl flex-col gap-6 px-4 py-10 text-sm text-muted-foreground sm:px-6">
          <div className="h-px w-full bg-brand-50" aria-hidden="true" />
          <div className="flex flex-col gap-4 sm:flex-row sm:items-baseline sm:justify-between">
            <div className="space-y-1">
              {hasBrandName ? (
                <p className="text-xs font-semibold uppercase tracking-[0.2em] text-muted-foreground">{brandName}</p>
              ) : null}
              {site.tagline ? (
                <p className="max-w-xl text-base text-muted-foreground">{site.tagline}</p>
              ) : null}
            </div>
            {hasContacts ? (
              <div className="flex flex-wrap items-center gap-3 text-sm sm:gap-4">
                {contactLinks.map((link) => (
                  <a
                    key={`footer-${link.id}`}
                    className="text-muted-foreground transition hover:text-foreground focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-600"
                    href={link.href}
                  >
                    {link.label}
                  </a>
                ))}
                {site.contacts.address ? (
                  <span className="text-xs text-muted-foreground sm:text-sm">{site.contacts.address}</span>
                ) : null}
              </div>
            ) : null}
          </div>
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <NavigationList
              links={navigation.footer}
              ariaLabel={navigationLabels.footerLabel}
              currentPath={currentPath}
            />
            {hasCopyright ? <p className="text-xs text-muted-foreground">{copyrightText}</p> : null}
          </div>
        </div>
      </footer>
    </div>
  );
}