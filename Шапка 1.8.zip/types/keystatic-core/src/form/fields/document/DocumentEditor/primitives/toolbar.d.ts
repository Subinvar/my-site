export declare const ToolbarSeparator: () => import("react").JSX.Element;
