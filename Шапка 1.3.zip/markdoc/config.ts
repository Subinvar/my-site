import { keystaticMarkdocConfig } from "../src/lib/markdoc";

export default keystaticMarkdocConfig;